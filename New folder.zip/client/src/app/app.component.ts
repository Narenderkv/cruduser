import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { NgxSmartModalService } from 'ngx-smart-modal';
import { ApiService } from './api.service';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.scss' ]
})
export class AppComponent {
  name = 'Angular 6';
  @ViewChild('myform') form: NgForm | undefined;
  data: any;
  editMode = false;
  editIndex: any;
  addForm: FormGroup | any;
bodyparser:any
  get f() { return this.addForm.controls; }

  constructor(private fb: FormBuilder, public ngxSmartModalService: NgxSmartModalService, private apiservice: ApiService) {
    this.list();
  }

  ngOnInit(): void {
    this.addForm = this.fb.group({
        name: ['', Validators.required], 
    surname: ['', [Validators.required]],
    id: [''], 
    });
  }

  list() {
    this.apiservice.post("employee_detail", { id: "",keyword:this.bodyparser }).subscribe((res: any) => {
      this.data = res.data;
      console.log("data", this.data);
    });
  }

  addData() {
    var val: any = this.addForm.value;
    console.log(val, 'this is data');
    this.addForm.get('name').markAsTouched();
    this.addForm.get('surname').markAsTouched();
    if(this.addForm.invalid){
      console.log("abcccc");
      
      return
    }else{
    this.apiservice.post("add_employee", val).subscribe((res: any) => {
      this.list();
this.addForm.reset();
      this.ngxSmartModalService.close('myModal');
    });
  }
  }

  onDel(id: any) {
    this.apiservice.post("emp_delete", { id: id }).subscribe((res: any) => {
            this.list();

    });

  }

  onEdit(index: any) {
    
    this.editMode = true;
    this.editIndex = index;
    this.ngxSmartModalService.open('myModal');
    this.addForm.patchValue(index);
  }

  closeModal(id: any) {
    this.form?.resetForm();
    this.editMode = false;
    this.ngxSmartModalService.close(id);
  }
  onSearchKey(value:any){
    console.log("hello",value.value);
    this.bodyparser=value.value
    this.list()

  }
}

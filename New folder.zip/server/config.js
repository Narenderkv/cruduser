var config = {}

config.port				 = 8999;
config.mysql_host		 = 'localhost';
config.mysql_user		 = 'root';
config.mysql_password	 = 'root';
config.mysql_database	 = 'employee';
config.appUrl	 	 	 = 'http://localhost:'+config.port;
config.SiteUrl	 	 	 = 'http://localhost:8999/';

config.DEBUG		     = 1;
config.rootUrl  	     = process.env.ROOT_URL  || 'https://localhost:'+config.port+'/';
module.exports 			 = config;
